export const GET_YEAR_ROLLER = 'GET_YEAR_ROLLER';
export const RETURN_YEAR_ROLLER = 'RETURN_YEAR_ROLLER';
export const ERROR_YEAR_ROLLER = 'ERROR_YEAR_ROLLER';

export const GET_OBJECTIVES = 'GET_OBJECTIVES';
export const RETURN_OBJECTIVES = 'RETURN_OBJECTIVES';
export const ERROR_OBJECTIVES = 'ERROR_OBJECTIVES';


export const getYearRoller = (params) => ({type: GET_YEAR_ROLLER, params});
export const getObjectives = (params) => ({type: GET_OBJECTIVES, params});