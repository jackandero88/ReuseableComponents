export const GET_JUDGEMENT_INFO = 'GET_JUDGEMENT_INFO';
export const RETURN_JUDGEMENT_INFO = 'RETURN_JUDGEMENT_INFO';
export const ERROR_JUDGEMENT_INFO = 'ERROR_JUDGEMENT_INFO';


export const getJudgementInfo = () => ({type: GET_JUDGEMENT_INFO});
