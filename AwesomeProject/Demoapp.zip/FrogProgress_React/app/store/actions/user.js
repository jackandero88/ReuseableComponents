export const GET_USER_INFO = 'GET_USER_INFO';
export const RETURN_USER_INFO = 'RETURN_USER_INFO';
export const ERROR_USER_INFO = 'ERROR_USER_INFO';


export const getUserInfo = () => ({type: GET_USER_INFO});
export const returnUserInfo = () => (
    {
        type: RECEIVE_MY_TRACKERS,
        payload: {asdfa}
    }
);