
import * as Routes from './routes'

export { Routes }