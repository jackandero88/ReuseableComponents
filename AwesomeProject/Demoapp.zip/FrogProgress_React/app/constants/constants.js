export const CONSUMER_KEY = 'qj9dvvss3bogrryquze5c52alzxyjlnf'
export const CONSUMER_SECRET = 'j4uff38y4qg88j0edxyf7dep4dn095whsia9ms5e'