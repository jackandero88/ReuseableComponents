import * as App from './app';

export { App };