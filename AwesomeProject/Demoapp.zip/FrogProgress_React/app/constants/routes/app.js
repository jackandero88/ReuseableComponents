export const Login = 'Login';
export const Home = 'Home';
export const Trackers = 'Trackers';
export const Objectives = 'Objectives';